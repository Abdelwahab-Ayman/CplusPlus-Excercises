#### Lesson 1- Hello World
 - 1. Find out what is the difference between a “signed” and an “unsigned” integer. When might you
 use an unsigned integer instead of a signed integer?
 - 2. You have seen the “fundamental data type” called int but you will eventually need to use others.
 Amend the program to create a char data type, a bool data type and a double data type. Give
 them appropriate names and values and print their values to screen using cout.
 - 3. Amend the code so that it asks for two numbers from the user. Store these numbers in separate
 integer variables and then print to screen their sum and product on separate lines. Use cin and
 cout—as well as the new line charactor—to accomplish this task.
 - 4. Amend the code from Lesson 1 so that the program asks for your first name and then prints
 “Hello (your name)!” to the screen. Use the cin and cout classes to accomplish this. In
 addition, use the string variable type in the std namespace to store your name.
