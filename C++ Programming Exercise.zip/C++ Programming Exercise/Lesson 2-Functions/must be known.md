1. type heirarchy in c++
2. implicit and explicit conversion
3. type conversion in c++
4. void return function
5. char type and string and integar

