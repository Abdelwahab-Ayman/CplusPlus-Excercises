 #### Lesson 2- Functions
 - 1. Not every function we may write has to return a value. Write a function called product which
 accepts two integers as arguments (like add and minus) but returns no value. In the function
 body the product function should use cout to print the product directly to screen.
 - 2. Write a function called quotient which should take a double argument and an integer argument.
 This function should also return a double data type. Now if you provide the quotient function
 with the values 5 and 3 say, it should return the value 1.66667 or there-abouts. Test this by
 calling the function within a cout statement. Once this works change the double argument to
 an integer and notice the result; why does quotient no longer return a double?
 - 3. Write a “calculator program” which asks for two numbers and a mathematical operator (repre
sented as a char type. Depending on the operator (+,-, * or /) call the appropriate function
 and display the result. Use a switch statement to filter the choices.
